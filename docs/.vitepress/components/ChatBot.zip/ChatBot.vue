<template>
  <div class="chatbot-container">
    <!-- 聊天机器人触发按钮 -->
    <div 
      class="chatbot-trigger" 
      @click="toggleChat"
      :class="{ 'active': isOpen }"
    >
      <svg v-if="!isOpen" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2ZM20 16H5.17L4 17.17V4H20V16Z" fill="currentColor"/>
        <circle cx="8" cy="10" r="1" fill="currentColor"/>
        <circle cx="12" cy="10" r="1" fill="currentColor"/>
        <circle cx="16" cy="10" r="1" fill="currentColor"/>
      </svg>
      <svg v-else width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="currentColor"/>
      </svg>
    </div>

    <!-- 聊天窗口 -->
    <div class="chatbot-window" v-show="isOpen">
      <div class="chatbot-header">
        <h3>智能助手</h3>
        <div class="connection-status" :class="{ 'connected': isConnected }">
          <span class="status-dot"></span>
          {{ isConnected ? '已连接' : '未连接' }}
        </div>
      </div>
      
      <div class="chatbot-messages" ref="messagesContainer">
        <div 
          v-for="(message, index) in messages" 
          :key="index" 
          class="message" 
          :class="{ 'user': message.type === 'user', 'bot': message.type === 'bot', 'error': message.type === 'error' }"
        >
          <div class="message-content">
            <div class="message-text" v-html="formatMessage(message.content)"></div>
            <div v-if="message.sources && message.sources.length > 0" class="message-sources">
              <details>
                <summary>参考来源 ({{ message.sources.length }})</summary>
                <div class="sources-list">
                  <div v-for="(source, idx) in message.sources" :key="idx" class="source-item">
                    <strong>{{ source.source }}</strong>
                    <p>{{ source.content.substring(0, 200) }}...</p>
                  </div>
                </div>
              </details>
            </div>
            <div v-if="message.feedback" class="message-feedback">
              <div class="feedback-info">
                <span v-if="message.feedback.is_improved" class="improved-badge">✨ 已优化</span>
                <span class="confidence">置信度: {{ (message.feedback.confidence_score * 100).toFixed(1) }}%</span>
              </div>
            </div>
          </div>
          <div class="message-time">{{ formatTime(message.timestamp) }}</div>
        </div>
        
        <div v-if="isLoading" class="message bot loading">
          <div class="message-content">
            <div class="typing-indicator">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
        </div>
      </div>
      
      <div class="chatbot-input">
        <div class="input-container">
          <textarea 
            v-model="currentMessage" 
            @keydown.enter.prevent="sendMessage"
            @keydown.shift.enter="addNewLine"
            placeholder="输入您的问题... (Shift+Enter 换行，Enter 发送)"
            rows="1"
            ref="messageInput"
            :disabled="isLoading"
          ></textarea>
          <button 
            @click="sendMessage" 
            :disabled="!currentMessage.trim() || isLoading"
            class="send-button"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2.01 21L23 12L2.01 3L2 10L17 12L2 14L2.01 21Z" fill="currentColor"/>
            </svg>
          </button>
        </div>
        <div class="input-options">
          <label class="checkbox-label">
            <input type="checkbox" v-model="useFeedback">
            使用反馈优化
          </label>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick, watch } from 'vue'
import grpcProto from './generated/knowledge_service_grpc_web_pb.js'
import protoService from './generated/knowledge_service_pb.js'

// 从proto对象中提取需要的类
const { ChatRequest, ChatResponse } = protoService
const { KnowledgeServicePromiseClient } = grpcProto

// 响应式数据
const isOpen = ref(false)
const isConnected = ref(false)
const isLoading = ref(false)
const currentMessage = ref('')
const useFeedback = ref(true)
const messages = ref([])
const messagesContainer = ref(null)
const messageInput = ref(null)

// gRPC 客户端
let grpcClient = null

// 初始化 gRPC 客户端
const initGrpcClient = () => {
  try {
    grpcClient = new KnowledgeServicePromiseClient('http://127.0.0.1:50051')
    isConnected.value = true
    console.log('gRPC 客户端初始化成功')
  } catch (error) {
    console.error('gRPC 客户端初始化失败:', error)
    isConnected.value = false
  }
}

// 切换聊天窗口
const toggleChat = () => {
  isOpen.value = !isOpen.value
  if (isOpen.value && messages.value.length === 0) {
    // 添加欢迎消息
    messages.value.push({
      type: 'bot',
      content: '您好！我是智能助手，可以帮助您解答关于文档的问题。请随时向我提问！',
      timestamp: new Date()
    })
  }
  nextTick(() => {
    if (isOpen.value && messageInput.value) {
      messageInput.value.focus()
    }
  })
}

// 发送消息
const sendMessage = async () => {
  if (!currentMessage.value.trim() || isLoading.value) return
  
  const userMessage = currentMessage.value.trim()
  currentMessage.value = ''
  
  // 添加用户消息
  messages.value.push({
    type: 'user',
    content: userMessage,
    timestamp: new Date()
  })
  
  // 滚动到底部
  scrollToBottom()
  
  if (!grpcClient) {
    messages.value.push({
      type: 'error',
      content: '连接失败，请检查服务器是否正常运行',
      timestamp: new Date()
    })
    return
  }
  
  isLoading.value = true
  
  try {
    // 创建请求
    const request = new ChatRequest()
    request.setQuestion(userMessage)
    request.setUseFeedback(useFeedback.value)
    
    // 发送请求
    const response = await grpcClient.chat(request)
    
    if (response.getSuccess()) {
      // 添加机器人回复
      const botMessage = {
        type: 'bot',
        content: response.getFinalAnswer() || response.getOriginalAnswer(),
        timestamp: new Date(),
        sources: response.getSourceDocumentsList().map(doc => ({
          content: doc.getContent(),
          source: doc.getSource(),
          metadata: doc.getMetadataMap()
        })),
        feedback: response.getFeedbackInfo() ? {
          is_improved: response.getFeedbackInfo().getIsImproved(),
          confidence_score: response.getFeedbackInfo().getConfidenceScore(),
          feedback_count: response.getFeedbackInfo().getFeedbackCount()
        } : null
      }
      
      messages.value.push(botMessage)
    } else {
      messages.value.push({
        type: 'error',
        content: response.getErrorMessage() || '服务器返回错误',
        timestamp: new Date()
      })
    }
  } catch (error) {
    console.error('发送消息失败:', error)
    messages.value.push({
      type: 'error',
      content: '网络错误，请稍后重试',
      timestamp: new Date()
    })
  } finally {
    isLoading.value = false
    scrollToBottom()
  }
}

// 添加换行
const addNewLine = () => {
  currentMessage.value += '\n'
}

// 滚动到底部
const scrollToBottom = () => {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

// 格式化消息内容
const formatMessage = (content) => {
  return content.replace(/\n/g, '<br>')
}

// 格式化时间
const formatTime = (timestamp) => {
  return timestamp.toLocaleTimeString('zh-CN', { 
    hour: '2-digit', 
    minute: '2-digit' 
  })
}

// 监听消息变化，自动滚动
watch(messages, () => {
  scrollToBottom()
}, { deep: true })

// 组件挂载时初始化
onMounted(() => {
  initGrpcClient()
})
</script>

<style scoped>
.chatbot-container {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 1000;
}

.chatbot-trigger {
  width: 60px;
  height: 60px;
  background: #007acc;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 4px 12px rgba(0, 122, 204, 0.3);
  transition: all 0.3s ease;
  color: white;
}

.chatbot-trigger:hover {
  background: #005a9e;
  transform: scale(1.05);
}

.chatbot-trigger.active {
  background: #dc3545;
}

.chatbot-window {
  position: absolute;
  bottom: 80px;
  right: 0;
  width: 400px;
  height: 600px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border: 1px solid #e1e5e9;
}

.chatbot-header {
  background: #007acc;
  color: white;
  padding: 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.chatbot-header h3 {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
}

.connection-status {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  opacity: 0.9;
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #dc3545;
  transition: background-color 0.3s ease;
}

.connection-status.connected .status-dot {
  background: #28a745;
}

.chatbot-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.message {
  display: flex;
  flex-direction: column;
  max-width: 85%;
}

.message.user {
  align-self: flex-end;
}

.message.bot,
.message.error {
  align-self: flex-start;
}

.message-content {
  padding: 12px 16px;
  border-radius: 18px;
  word-wrap: break-word;
}

.message.user .message-content {
  background: #007acc;
  color: white;
}

.message.bot .message-content {
  background: #f1f3f4;
  color: #333;
}

.message.error .message-content {
  background: #fee;
  color: #d63384;
  border: 1px solid #f5c6cb;
}

.message-text {
  line-height: 1.4;
}

.message-sources {
  margin-top: 8px;
  font-size: 12px;
}

.message-sources details {
  cursor: pointer;
}

.message-sources summary {
  color: #666;
  font-weight: 500;
}

.sources-list {
  margin-top: 8px;
  padding-left: 12px;
}

.source-item {
  margin-bottom: 8px;
  padding: 8px;
  background: #f8f9fa;
  border-radius: 6px;
  border-left: 3px solid #007acc;
}

.source-item strong {
  display: block;
  margin-bottom: 4px;
  color: #007acc;
}

.source-item p {
  margin: 0;
  color: #666;
  font-size: 11px;
  line-height: 1.3;
}

.message-feedback {
  margin-top: 8px;
  font-size: 11px;
}

.feedback-info {
  display: flex;
  gap: 8px;
  align-items: center;
}

.improved-badge {
  background: #28a745;
  color: white;
  padding: 2px 6px;
  border-radius: 10px;
  font-size: 10px;
}

.confidence {
  color: #666;
}

.message-time {
  font-size: 11px;
  color: #999;
  margin-top: 4px;
  align-self: flex-end;
}

.message.user .message-time {
  align-self: flex-end;
}

.message.bot .message-time,
.message.error .message-time {
  align-self: flex-start;
}

.loading .message-content {
  background: #f1f3f4;
}

.typing-indicator {
  display: flex;
  gap: 4px;
  align-items: center;
}

.typing-indicator span {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #999;
  animation: typing 1.4s infinite ease-in-out;
}

.typing-indicator span:nth-child(1) {
  animation-delay: -0.32s;
}

.typing-indicator span:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes typing {
  0%, 80%, 100% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}

.chatbot-input {
  border-top: 1px solid #e1e5e9;
  padding: 16px;
}

.input-container {
  display: flex;
  gap: 8px;
  align-items: flex-end;
}

.input-container textarea {
  flex: 1;
  border: 1px solid #ddd;
  border-radius: 20px;
  padding: 10px 16px;
  resize: none;
  font-family: inherit;
  font-size: 14px;
  line-height: 1.4;
  max-height: 100px;
  min-height: 40px;
}

.input-container textarea:focus {
  outline: none;
  border-color: #007acc;
}

.input-container textarea:disabled {
  background: #f5f5f5;
  cursor: not-allowed;
}

.send-button {
  width: 40px;
  height: 40px;
  border: none;
  border-radius: 50%;
  background: #007acc;
  color: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s ease;
}

.send-button:hover:not(:disabled) {
  background: #005a9e;
}

.send-button:disabled {
  background: #ccc;
  cursor: not-allowed;
}

.input-options {
  margin-top: 8px;
  display: flex;
  justify-content: flex-start;
}

.checkbox-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: #666;
  cursor: pointer;
}

.checkbox-label input[type="checkbox"] {
  margin: 0;
}

/* 响应式设计 */
@media (max-width: 480px) {
  .chatbot-window {
    width: calc(100vw - 40px);
    height: calc(100vh - 140px);
    right: 20px;
  }
  
  .chatbot-trigger {
    width: 50px;
    height: 50px;
  }
}

/* 滚动条样式 */
.chatbot-messages::-webkit-scrollbar {
  width: 6px;
}

.chatbot-messages::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 3px;
}

.chatbot-messages::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 3px;
}

.chatbot-messages::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}
</style>